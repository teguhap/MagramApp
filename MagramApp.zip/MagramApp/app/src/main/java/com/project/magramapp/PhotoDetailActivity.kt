package com.project.magramapp

import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import com.project.magramapp.databinding.ActivityPhotoDetailBinding
import com.squareup.picasso.Picasso
import java.lang.Float.max
import java.lang.Float.min

class PhotoDetailActivity : AppCompatActivity() {
    lateinit var binding : ActivityPhotoDetailBinding
    private lateinit var scaleGestureDetector: ScaleGestureDetector
    private var scaleFactor = 1.0f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPhotoDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)



        val title = intent.getStringExtra("title")
        val url = intent.getStringExtra("url")


        Picasso.get().load(url).fit().into(binding.ivPhoto)
        binding.tvPhotoTitle.text = title
        scaleGestureDetector = ScaleGestureDetector(this, ScaleListener())
    }


    override fun onTouchEvent(motionEvent: MotionEvent): Boolean {
        scaleGestureDetector.onTouchEvent(motionEvent)
        return true
    }

    private inner class ScaleListener : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(scaleGestureDetector: ScaleGestureDetector): Boolean {
            scaleFactor *= scaleGestureDetector.scaleFactor
            scaleFactor = max(0.1f, min(scaleFactor, 10.0f))
            binding.ivPhoto.scaleX = scaleFactor
            binding.ivPhoto.scaleY = scaleFactor
            return true
        }
    }


}