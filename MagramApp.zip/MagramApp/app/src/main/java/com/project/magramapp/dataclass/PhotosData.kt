package com.project.magramapp.dataclass

data class PhotosData(val albumId:String,val id:String,val title:String,val url : String, val thumbnailUrl:String)
