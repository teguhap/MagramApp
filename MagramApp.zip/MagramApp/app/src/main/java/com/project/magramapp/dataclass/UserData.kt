package com.project.magramapp.dataclass

import java.net.Inet4Address

data class UserData(val id : String,val name :String ,val email:String,val companyName : String ,val address: String)
