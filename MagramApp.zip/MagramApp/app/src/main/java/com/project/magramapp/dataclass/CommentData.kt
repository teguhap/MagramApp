package com.project.magramapp.dataclass

data class CommentData(val postId : String,val id : String,val username : String,val email : String,val body : String)
