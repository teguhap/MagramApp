package com.project.magramapp.dataclass

data class ListPostAdapter(val userId:String, val idPost : String, val title : String, val body : String, val username : String, val company : String)
