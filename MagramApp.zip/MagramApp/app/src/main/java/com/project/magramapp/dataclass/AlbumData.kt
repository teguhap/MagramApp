package com.project.magramapp.dataclass

data class AlbumData(val id : String,val title : String)
